# LAP dataset

The LAP dataset can be downloaded from the following site.

http://chalearnlap.cvc.uab.es/dataset/19/description/

As the dataset is included in the APPA-REAL dataset, I recommend to use it instead of the LAP dataset.
